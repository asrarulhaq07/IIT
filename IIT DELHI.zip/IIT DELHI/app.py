# app.py
from flask import Flask, render_template, request, redirect,url_for, session,flash
from datetime import timedelta
from importlib import reload
from werkzeug.utils import secure_filename
import sqlite3
import pytesseract
from PIL import ImageFilter, Image
import os
import sys
import cv2
import hashlib
import numpy as np
import imutils
from pdf2image import convert_from_path

reload(sys)
# if no media folder, create one
if not os.path.isdir('media'):
    os.mkdir('media')

# if no database, create one
if not os.path.isfile('IITDELHI.db'):
    conn = sqlite3.connect('IITDELHI.db')
    c = conn.cursor()
    # create database that saves hash of image and text
    # unique hash is used to prevent duplicate images
    c.execute('''CREATE TABLE IITDELHI (hash text UNIQUE, text BLOB)''')
    conn.commit()
    conn.close()

# if no templates folder, create one
if not os.path.isdir('templates'):
    os.mkdir('templates')
# add upload folder as media in current directory
UPLOAD_FOLDER = './media'
app=Flask(__name__, static_url_path='/media', static_folder='media')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set a secret key for securely signing the session cookie
app.secret_key = "mysecretkey"
app.permanent_session_lifetime = timedelta(minutes=5)

valid_users = {"chetan": "chetan", "user2": "password2"}

@app.route("/")
def base():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    password = request.form["password"]

    if username in valid_users and valid_users[username] == password:
        session.permanent = True
        session["username"] = username
        return redirect("/index")
    else:
        error='Invalid Username Or Password'
        return render_template('login.html',error=error)
@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect("/")


@app.route('/submitImage',methods=['POST',])
def submitImage():
    # if file is not image or pdf, popup invalid file and return to index.html
    file = request.files['file']
    text=''
    if not file.filename:
        return render_template('index.html', message='No file selected')
    elif not file.filename.endswith(('.png', '.jpg', '.jpeg', '.pdf')):
        return render_template('index.html', message='Invalid file')

    else:
        # if file is image, save image to media folder and do word segmentation
        if file.filename.endswith(('.png', '.jpg', '.jpeg')):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            img = Image.open(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            
            image = cv2.imread(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            text = pytesseract.image_to_string(img)
            f = open(os.path.join(app.config['UPLOAD_FOLDER'], filename)+'.txt','w')
            f.write(text)
            f.close()
            # Convert the image to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Apply thresholding to the image to create a binary image
            thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]

            # Find the horizontal and vertical lines in the image
            horizontal_lines = cv2.HoughLinesP(thresh, 1, np.pi/180, 100, minLineLength=100, maxLineGap=50)
            vertical_lines = cv2.HoughLinesP(thresh, 1, np.pi/180, 100, minLineLength=100, maxLineGap=50)

            # Create a copy of the image to draw the lines on
            line_image = image.copy()

            # Draw the horizontal lines on the image
            for line in horizontal_lines:
                x1, y1, x2, y2 = line[0]
                cv2.line(line_image, (x1, y1), (x2, y2), (255, 0, 0), 3)

            # Draw the vertical lines on the image
            for line in vertical_lines:
                x1, y1, x2, y2 = line[0]
                cv2.line(line_image, (x1, y1), (x2, y2), (255, 0, 0), 3)

            # save line_image to media folder as line_image +filename
            cv2.imwrite('media/line_'+file.filename, line_image)
            conn=sqlite3.connect('IITDELHI.db')
            c=conn.cursor()
            file_hash = hashlib.md5(open(os.path.join(app.config['UPLOAD_FOLDER'], filename),'rb').read()).hexdigest()
            # if hash already exists, return result.html with image
            if c.execute("SELECT * FROM IITDELHI WHERE hash=?", (file_hash,)).fetchone():
                conn.commit()
                conn.close()
                return render_template('result.html', image='media/line_'+file.filename)
            c.execute("INSERT INTO IITDELHI (hash,text) VALUES(?,?)", (file_hash,'line_'+file.filename))
            conn.commit()
            conn.close()
            image=cv2.imread(os.path.join(app.config['UPLOAD_FOLDER'], 'line_'+file.filename))
            return render_template('result.html', image=image,text=text)


if __name__ == "__main__":
    app.run('0.0.0.0',2000, debug=True)